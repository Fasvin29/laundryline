<?php
include 'header.php';
?>
        
        <!-- Page Header Start -->
        <div class="container-fluid page-header py-5 my-5">
            <div class="container text-center py-5">
                <h1 class="display-2 text-white mb-4 animated slideInDown">About</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0 animated slideInDown">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item text-white" aria-current="page">About</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->



 <div class="container-fluid">
            <div class="container">
                <div class="row g-5 d-flex justify-content-center">
                    <div class="col-12 col-md-4 wow fadeInUp" data-wow-delay=".3s" style="height: 384px;;">
                        <div class="about-img h-100">
                            <div class="rotate-left bg-dark"></div>
                            <div class="rotate-right bg-dark"></div>
                            <img src="img/about.png" class="img-fluid h-100" alt="img">
                            <div class="bg-white experiences">
                                <h1 class="display-3">07</h1>
                                <h6 class="fw-bold">Years Of Experiences</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay=".6s">
                        <div class="about-item overflow-hidden">
                            <h5
                                class="mb-2 px-3 py-1 text-dark rounded-pill d-inline-block border border-2 border-primary">
                                About Laundry Line</h5>
                            <h1 class="display-5 mb-2">Laundry Line</h1>
                            <p class="fs-" style="text-align: justify;">Our team of professionals are unmatched in their
                                knowledge and expertise in the laundry and linen service industry. In addition to
                                providing
                                high quality linen processing, we partner with our members to enhance services and
                                reduce
                                operating costs. The advanced machinery used allows us to wash linen utilising up to 75%
                                less water, chemicals, and energy. We continue to find new ways to improve and expand
                                our
                                environmental awareness initiatives such as water conservation and degradable chemicals.
                                A
                                revolution in laundry services in the city of Mangalore!

                                Perfection is what you will get from us at all times. With our innovative laundry
                                services
                                and technology, your laundry will be delicately handled using methods that are
                                undoubtedly
                                the best. We ensure your laundry is presented back to you spotlessly clean, immaculately
                                fresh and with top notch finesse, giving you the most impeccable laundry services.</p>
                            <!-- <div class="row">
                            <div class="col-3">
                                <div class="text-center">
                                    <div class="p-4 bg-dark rounded d-flex"
                                        style="align-items: center; justify-content: center;">
                                        <i class="fas fa-city fa-4x text-primary"></i>
                                    </div>
                                    <div class="my-2">
                                        <h5>Building</h5>
                                        <h5>Cleaning</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="text-center">
                                    <div class="p-4 bg-dark rounded d-flex"
                                        style="align-items: center; justify-content: center;">
                                        <i class="fas fa-school fa-4x text-primary"></i>
                                    </div>
                                    <div class="my-2">
                                        <h5>Education</h5>
                                        <h5>center</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="text-center">
                                    <div class="p-4 bg-dark rounded d-flex"
                                        style="align-items: center; justify-content: center;">
                                        <i class="fas fa-warehouse fa-4x text-primary"></i>
                                    </div>
                                    <div class="my-2">
                                        <h5>Warehouse</h5>
                                        <h5>Cleaning</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="text-center">
                                    <div class="p-4 bg-dark rounded d-flex"
                                        style="align-items: center; justify-content: center;">
                                        <i class="fas fa-hospital fa-4x text-primary"></i>
                                    </div>
                                    <div class="my-2">
                                        <h5>Hospital</h5>
                                        <h5>Cleaning</h5>
                                    </div>
                                </div>
                            </div>
                        </div> 
                      <button type="button" class="btn btn-primary border-0 rounded-pill px-4 py-3 mt-1">Learn
                            more</button> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>






<?php
include 'footer.php';
?>
