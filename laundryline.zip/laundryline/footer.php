
    <!-- Footer Start -->
    <section id="footer">
        <div class="container-fluid footer wow fadeIn" data-wow-delay=".3s">
            <div class="container py-5">
                <form action="" id="footer-form">
                    <h5 class="text-white fw-bold mb-4">Subscribe To Our Services</h5>
                    <div class="row">
                        <div class="col-12 col-md-4 col-lg-3">
                            <input type="text" name="name" class="form-control border-0 rounded px-4 py-3 m-2"
                                placeholder="Enter Your Name" required>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <input type="email" name="email" class="form-control border-0 rounded px-4 py-3 m-2"
                                placeholder="Enter Your Email Address" required>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <input type="number" name="phone" class="form-control border-0 rounded px-4 py-3 m-2"
                                placeholder="Enter Your Phone Number" required>
                        </div>
                        <div class="col-12 col-lg-3 d-flex justify-content-center">
                            <button class="btn btn-primary border-0 rounded px-4 py-3 m-2"
                                type="submit">Subscribe</button>
                        </div>

                    </div>
                    <!-- <div class="input-group flex-column flex-md-row">
                    </div> -->
                </form>
                <hr>
                <div class="row g-4 footer-inner mt-3">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">LAUNDRY LINE BALMATA</h6>
                            <p>YCC Building Balmata Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                8971533055</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">LAUNDRY LINE KADRI</h6>
                            <p>Yenepoya Mall, Ground floor , Kadri Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                8861088808</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">LAUNDRY LINE JEPPU</h6>
                            <p>Mphasis campus Morgansgate ,Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026011655</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">LAUNDRY LINE PANDESHWARA</h6>
                            <p>Minaz complex , Pandeshwara Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                9071710086</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC KADRI</h6>
                            <p>Kadri petrol pump ,Kadri Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026578855</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC BALMATA</h6>
                            <p>Prabhu service station, Balmata Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026498855</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC MANGALADEVI</h6>
                            <p>Mahalasa Fuel, IOC Petrol pump , Mangaladevi</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026728855</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC MANNAGUDDA</h6>
                            <p>Ashirvad Enterprises ,IOC Petrol pump Manngudda</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026218855</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC DERALAKATTE</h6>
                            <p>Coco petrol pump , Deralakatte Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026458855</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC KALLAPU</h6>
                            <p>Kallapu service station, IOC petrol pump Kallapu</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026277739</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC CAPITANIO</h6>
                            <p>KG Bhat service station , Capitanio Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026277737</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC KOTTARA</h6>
                            <p>Pramod enterprise, IOC petrol pump Kottara chowki</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026277787</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC BC ROAD</h6>
                            <p>Padma services , IOC Petrol pump BC Road Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026277715</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">IOC BEJAI</h6>
                            <p>Bejai service station ,IOC Petrol pump Bejai Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                7026277756</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer">
                            <h6 class="text-white fw-bold ">HOME DELIVERY</h6>
                            <p>Mphasis campus Morgansgate ,Mangalore</p>
                            <a href="tel:+918861088808" class="text-success fw-bold"><i class="fas fa-phone-alt"></i>
                                8971499055</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-item tight-footer text-center">
                            <h4 class="text-white fw-bold ">For Door Delivery & Pickup</h4>
                            <h5 class="text-danger">(Free delivery for orders above Rs.300)</h5>
                            <!-- <a href="tel:+918971499055"><i class="fas fa-phone-alt"></i> 8971 499055</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-lg-3 col-md-6">
            <div class="footer-item">
                <h4 class="text-white fw-bold mb-4">Contact Us</h4>
                <a href="" class="btn btn-link w-100 text-start ps-0 pb-3 border-bottom rounded-0"><i
                        class="fa fa-map-marker-alt me-3"></i>123 Street, CA, USA</a>
                <a href="" class="btn btn-link w-100 text-start ps-0 py-3 border-bottom rounded-0"><i
                        class="fa fa-phone-alt me-3"></i>+012 345 67890</a>
                <a href="" class="btn btn-link w-100 text-start ps-0 py-3 border-bottom rounded-0"><i
                        class="fa fa-envelope me-3"></i>info@example.com</a>
            </div>
        </div> -->
        </div>
        </div>
        </div>
        <!-- Footer End -->



        <!-- Copyright Start -->
        <div class="container-fluid copyright bg-dark py-4">
            <div class="container">
                <div class="row align-items-center text-center text-md-start">
                    <!-- Logo -->
                    <div class="col-md-4 mb-3 mb-md-0">
                        <a href="index.php"><img src="img/laundrylogo.png" class="img-fluid" style="max-width: 120px;"
                                alt="Laundry Line Logo"></a>
                    </div>

                    <!-- Email and Phone -->
                    <div class="col-md-8 text-white">
                        <p
                            class="mb-0 d-flex flex-column flex-md-row justify-content-center justify-content-md-center align-items-center gap-3">
                            <a href="mailto:laundryline@yenepoya.org" class="text-white text-decoration-none">
                                <i class="fas fa-envelope me-2"></i>laundryline@yenepoya.org
                            </a>
                            <a href="tel:+917026612474" class="text-white text-decoration-none">
                                <i class="fas fa-phone-alt me-2"></i>7026612474
                            </a>
                        </p>
                    </div>
                    <!-- <div class="col-md-4 copyright-btn text-center text-md-start mb-3 mb-md-0 flex-shrink-0">
                    <a class="btn btn-primary rounded-circle me-3 copyright-icon" href=""><i
                            class="fab fa-twitter"></i></a>
                    <a class="btn btn-primary rounded-circle me-3 copyright-icon" href=""><i
                            class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-primary rounded-circle me-3 copyright-icon" href=""><i
                            class="fab fa-youtube"></i></a>
                    <a class="btn btn-primary rounded-circle me-3 copyright-icon" href=""><i
                            class="fab fa-linkedin-in"></i></a>
                </div> -->
                </div>
            </div>
        </div>
    </section>

    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary rounded-circle border-3 back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>