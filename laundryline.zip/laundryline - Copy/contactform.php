<?php
include 'connection.php';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "INSERT INTO contactform (name, email, phone) VALUES ('$name', '$email', '$phone')";
    $data = mysqli_query($connection, $query);

    if ($data) {
        echo "<script>
        document.addEventListener('DOMContentLoaded', function () {
            var successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();
        });
    </script>";
    } else {
        echo '<div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                There was an error submitting your communication address. Please try again later.</div>';
    }
}

header("location: index.php");
?>
