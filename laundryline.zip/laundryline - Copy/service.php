<?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
<?php include('header.php'); ?>



<!-- Page Header Start -->
<div class="container-fluid page-header py-5">
    <div class="container text-center py-5">
        <h1 class="display-2 text-white my-5 animated slideInDown">Services</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center mb-0 animated slideInDown">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item text-white" aria-current="page">Services</li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->


<div class="container-fluid services">
    <div class="container text-center pt-5">
        <div class="text-center mb-5 wow fadeInUp" data-wow-delay=".3s">
            <h5 class="mb-2 px-3 text-dark rounded-pill d-inline-block border border-2 border-primary">Our
                Services</h5>
            <!-- <h1 class="display-5">Common Pest Control Services</h1> -->
        </div>
        <div class="row g-5">
            <div class=" col-md-6 col-sm-12 wow fadeInUp mt-4" data-wow-delay=".5s">
                <div class="bg-light rounded p-5 services-item">
                    <div class="d-flex" style="align-items: center; justify-content: center;">
                        <div class="mb-4 rounded-circle services-inner-icon">
                            <i class="fas fa-spray-can fa-3x text-primary"></i>
                        </div>
                    </div>
                    <h4 class="text-center">Individual Laundry</h4>
                    <p class="text-center fs-5">We offer reliable and hygienic laundry care for <strong>individuals
                            and families </strong>— from everyday wear to delicate garments, ensuring your clothes
                        are cleaned, pressed, and returned with utmost care and freshness.</p>
                    <!--<button type="button" class="btn btn-primary border-0 rounded-pill px-4 py-3">Learn
                                More</button> -->
                </div>
            </div>
            <div class=" col-md-6 col-sm-12 wow fadeInUp mt-4" data-wow-delay=".7s">
                <div class="bg-light rounded p-5 services-item">
                    <div class="d-flex" style="align-items: center; justify-content: center;">
                        <div class="mb-4 rounded-circle services-inner-icon">
                            <i class="fas fa-hospital fa-3x text-primary"></i>
                        </div>
                    </div>
                    <h4 class="text-center">Instituitional Laundry</h4>
                    <p class="text-center fs-5">We specialize in handling large-scale laundry requirements for
                        <strong>hospitals, hotels, educational institutions, hostels, and other organizations
                        </strong>— offering customized bulk order solutions with high efficiency and hygiene
                        standards.
                    </p>
                    <!--<button type="button" class="btn btn-primary border-0 rounded-pill px-4 py-3">Learn
                                More</button> -->
                </div>
            </div>
        </div>
        <!-- <button type="button" class="btn btn-primary border-0 rounded-pill px-4 py-3 mt-4 wow fadeInUp"
                data-bs-toggle="modal" data-bs-target="#booklaundry">
                Book Laundry
            </button> -->
    </div>

    <!-- book laundry Modal -->
    <div class="modal fade" id="booklaundry">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header border-0">
                    <div class="w-100 text-center">
                        <h4 class="modal-title text-white">Book Laundry</h4>
                        <p class="mb-2">Fill the form below to book your laundry service. <br>We will contact you
                            shortly.</p>
                    </div>
                    <button type="button" class="position-absolute top-0 end-0 m-3 border-0 bg-transparent"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times text-white fs-5"></i>
                    </button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body">
                    <form action="" id="footer-form">

                        <div class="mb-3">
                            <input type="text" name="name" id="name" class="form-control"
                                placeholder="Enter your Name" required>
                        </div>

                        <div class="mb-3">
                            <input type="email" name="email" id="email" class="form-control"
                                placeholder="Enter Your Email Address" required>
                        </div>

                        <div class="mb-3">
                            <input type="tel" name="phone" id="phone" class="form-control"
                                placeholder="Enter Your Phone Number" pattern="^(\+91[\-\s]?)?[6-9]{1}[0-9]{9}$"
                                title="Enter a valid Indian phone number (e.g. 9876543210 or +91-9876543210)"
                                required>
                        </div>


                        <div class="mb-3">
                            <select name="service" id="service" class="form-control" required>
                                <option value="" disabled selected>Select Service Type</option>
                                <option value="Individual">Individual Laundry</option>
                                <option value="Institutional">Institutional Laundry</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <textarea name="address" id="address" class="form-control" rows="3"
                                placeholder="Enter Your Address" required></textarea>
                        </div>

                        <div class="text-center">
                            <button class="btn btn-primary px-5 py-3" type="submit">Submit</button>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>


    <!-- our clients -->
    <?php
    include 'clients.php';
    ?>
    <!-- end of clients -->

    <?php
    include 'footer.php';
    ?>