<?php
$serverName ="localhost";
$username ="root";
$password ="";
$dbname = "laundryline";

$connection = mysqli_connect($serverName,$username,$password,$dbname);

// if($connection)
// {
//     echo "connected to database";
// }
// else
// {
//     echo "connection failed";
// }
?>