<!-- our clients -->
<div class="container-fluid mt-3 px-0">
    <div class="container-fluid pt-5 px-0 pb-5">
        <div class="text-center mb-4">
            <h5 class="mb-2 px-3 py-1 text-dark rounded-pill d-inline-block border border-2 border-primary">Our Trusted Clients
                </h5>
                <!-- <h4 class="text-center mb-4">Our Trusted Clients</h4> -->
            </div>
            
            <div id="client-marquee" class="py-3">
            <div class="logo-marquee border-0">
                <div class="logo-track ">

                    <img src="img/clients/client1.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client2.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client3.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client4.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client5.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client6.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client7.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client8.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client9.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client10.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client11.png" alt="Client 1" class="client-logo">

                </div>
            </div>

            <div id="logo-marquee2" class="logo-marquee border-0 mt-5">
                <div class="logo-track ">

                    <img src="img/clients/client12.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client13.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client14.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client15.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client16.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client17.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client18.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client19.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client20.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client21.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client22.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client23.png" alt="Client 1" class="client-logo">

                </div>
            </div>


            <div class="logo-marquee border-0 mt-5">
                <div class="logo-track ">
                    <img src="img/clients/client24.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client25.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client26.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client27.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client28.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client29.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client30.png" alt="Client 1" class="client-logo">
                    <!-- duplicate -->
                    <img src="img/clients/client24.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client25.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client26.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client27.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client28.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client29.png" alt="Client 1" class="client-logo">
                    <img src="img/clients/client30.png" alt="Client 1" class="client-logo">

                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of our clients -->